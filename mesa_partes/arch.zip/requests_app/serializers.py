from rest_framework import serializers
from .models import Request, RequestFile, RequestStatus
from files.serializers import FileSerializer
from users.serializers import AdminUserSerializer
from files.models import File
from mesa_partes.utils.response import custom_response
from django.utils import timezone
import re
from django.utils import timezone
class RequestFileSerializer(serializers.ModelSerializer):
    file = FileSerializer(read_only=True)

    class Meta:
        model = RequestFile
        fields = ["id", "file"]

class RequestStatusSerializer(serializers.ModelSerializer):
    changed_by = AdminUserSerializer(read_only=True)

    class Meta:
        model = RequestStatus
        fields = ["id", "status", "changed_at", "changed_by"]

class RequestSerializer(serializers.ModelSerializer):
    files = RequestFileSerializer(many=True, read_only=True)
    status_history = RequestStatusSerializer(many=True, read_only=True)

    class Meta:
        model = Request
        fields = [
            "id", "code", "full_name", "document", "email", "phone",
            "concept", "status", "created_at", "files", "status_history"
        ]
        read_only_fields = ["id", "created_at"]

class RequestCreateSerializer(serializers.ModelSerializer):
    uploaded_files = serializers.ListField(
        child=serializers.FileField(),
        write_only=True,
        required=True
    )

    class Meta:
        model = Request
        fields = ["full_name", "document", "email", "phone", "concept", "uploaded_files"]

    def create(self, validated_data):
        files_data = validated_data.pop("uploaded_files", [])

        last_request = Request.objects.order_by("-created_at").first()

        if last_request:
            match = re.search(r"(\d+)$", last_request.code)
            last_number = int(match.group(1)) if match else 0
            next_number = last_number + 1
        else:
            next_number = 1

        validated_data["code"] = f"TRM-{timezone.now().year}-{next_number:04d}"

        request_instance = Request.objects.create(**validated_data)

        for f in files_data:
            file_instance = File.objects.create(
                original_name=f.name,
                file_path=f,
                file_type=f.name.split(".")[-1].lower(),
                size=f.size
            )
            RequestFile.objects.create(request=request_instance, file=file_instance)

        return request_instance
    
class PublicRequestStatusSerializer(serializers.ModelSerializer):
    changed_by = serializers.SerializerMethodField()

    class Meta:
        model = RequestStatus
        fields = ["id", "status", "changed_at", "changed_by"]

    def get_changed_by(self, obj):
        if obj.changed_by:
            return {
                "id": obj.changed_by.id,
                "name": obj.changed_by.name,
                "email": obj.changed_by.email,
            }
        return None

class PublicRequestSerializer(serializers.ModelSerializer):
    files = RequestFileSerializer(many=True, read_only=True)
    status_history = PublicRequestStatusSerializer(many=True, read_only=True)

    class Meta:
        model = Request
        fields = ["id", "code", "full_name", "document", "email", "phone", "concept", "status", "created_at", "files", "status_history"]